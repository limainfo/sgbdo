#!/bin/sh

echo "\033[31m Informe o nome do arquivo de origem : \033[0m"
read ORIGEM

echo "\033[31m Informe a quantidade de copias : \033[0m"
read QTD

echo "\033[31m Informe o nome inicial para destino: \033[0m"
read DESTINO

i=1

while [ $i -le $QTD ]   
do
  eval "cp $ORIGEM $DESTINO$i.png"
  i=`expr $i + 1`
done

chown -R familia.familia *
chmod 777 *

