
		   $(function () {
			   
        $('#graficoh').highcharts({
            chart: {
                type: 'bar'
            },
            title: {
                text: 'Status Operacional do Efetivo'
            },
            xAxis: {
                categories: ['1º GCC','CGNA','CINDACTA I','CINDACTA II','CINDACTA III','CINDACTA IV','DECEA','ICA','ICEA','SRPV-SP','2/6 GAV','CIAAR','DAESP','EEAR','INFRAERO']
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Quantidade total do Efetivo Operacional'
                }
            },
            legend: {
                backgroundColor: '#FFFFFF',
                reversed: true
            },
            plotOptions: {
                series: {
                    stacking: 'normal'
                }
            },
			
                series: [{
                name: 'Operacionais',
                data: [ 5, 0, 140, 134, 374, 433, 2, 0, 0, 218, 0, 1, 0, 1, 82]
            }, {
                name: 'Não Operacional',
                data: [ 56, 25, 724, 715, 619, 421, 25, 2, 29, 589, 14, 11, 28, 28, 506]
            }
			]			
        });
    });
	
