Coldfusion example by Sidney Maestre
http://www.designovermatter.com/post.cfm/ajax-file-uploader-for-coldfusion

    1.  Unzip Andrew's AJAX Uploader into your web root.
    2.  Replace the demo.htm with demo.cfm in the "client" folder
    3.  Place coldfusion.cfc in the "server" folder 
    4.  Browse to the demo.cfm file and try it out. The file should be written to the "server" folder.

Questions? You can contact Sidney Maestreme by mail (sid.maestre(at)designovermatter.com) or Twitter @SidneyAllen